const { app, BrowserWindow } = require('electron')
const path = require('path')

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 600,
    title: '請求書集計 - RAT GARAGE',
    backgroundColor: '#0e0f11',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true
    }
  })
  win.loadFile('invoice-aggregator.html')
  win.setMenu(null)
}

app.whenReady().then(createWindow)
app.on('window-all-closed', () => app.quit())
