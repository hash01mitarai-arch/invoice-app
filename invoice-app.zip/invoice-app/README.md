# 請求書集計アプリ - ビルド手順

## 必要なもの
- Node.js (https://nodejs.org からインストール)

## .exe を作る手順

```
# このフォルダでコマンドプロンプトを開いて実行

npm install
npm run build
```

完了すると `dist/` フォルダに インストーラー (.exe) が生成されます。

## 動作確認（ビルドなし）

```
npm install
npm start
```

でウィンドウが開きます。
